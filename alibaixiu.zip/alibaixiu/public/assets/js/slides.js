// 设置-图片轮播界面

// 当管理员选择文件的时候
$('#file').on('change', function () {
	// 用户选择到的文件
	var file = this.files[0];
	// 创建formData对象实现二进制文件上传
	var formData = new FormData();
	// 将管理员选择到的文件添加到formData对象中
	formData.append('image', file);
	// 向服务器端发送请求 实现图片上传
	$.ajax({
		type: 'post',
		url: '/upload',
		data: formData,
		// 告诉$.ajax方法不要解析请求参数
		// 正常情况下回解析成'属性名=属性值&'的格式的
		// 但是这里是图片,就不用解析
		processData: false,
		// 告诉$.ajax方法不要设置请求参数的类型
		// 因为请求参数的类型在formData对象中已经设置了
		contentType: false,
		success: function (response) {
			// 上传之后的图片地址
			console.log(response[0].image)
			// 将上传之后的图片地址存储到隐藏域中
			$('#image').val(response[0].image)
		}
	})
});

// 当轮播图表单发生提交行为时
$('#slidesForm').on('submit', function () {
	// 获取管理员在表单中输入的内容
	var formData = $(this).serialize();
	// 向服务器端发送请求 添加轮播图数据
	$.ajax({
		type: 'post',
		url: '/slides',
		data: formData,
		success: function () {
			location.reload();
		}
	})
	// 阻止表单默认提交行为
	return false;
})

// 向服务器端发送请求 索要图片轮播列表数据
$.ajax({
	type: 'get',
	url: '/slides',
	success: function (response) {
		console.log(response)
		// 第二个参数是个对象
		var html = template('slidesTpl', {data: response});
		$('#slidesBox').html(html);
	}
})

// 当删除按钮被点击时
$('#slidesBox').on('click', '.delete', function () {
	if (confirm('您真的要进行删除操作吗')) {
		// 获取管理员要删除的轮播图数据id
		var id = $(this).attr('data-id');
		// 向服务器发送请求 实现轮播数据删除功能
		$.ajax({
			type: 'delete',
			url: '/slides/' + id,
			success: function () {
				location.reload();
			}
		})
	}
});

