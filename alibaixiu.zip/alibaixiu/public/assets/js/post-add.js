// 写文章界面js代码

// 向服务器端发送请求 获取文章分类数据
$.ajax({
	url: '/categories',
	type: 'get',
	success: function (response) {
		console.log(response)
		var html = template('categoryTpl', {data: response});
		$('#category').html(html);
	}
})

// 当管理员选择文件的时候 触发事件
$('#feature').on('change', function () {
	// 获取到管理员选择到的文件
	var file = this.files[0];
	// 创建formData对象 实现二进制文件上传
	var formData = new FormData();
	// 将管理员选择到的文件追加到formData对象中
	formData.append('cover', file);
	// 实现文章封面图片上传
	$.ajax({
		type: 'post',
		url: '/upload',
		data: formData,
		// 告诉$.ajax方法不要处理data属性对应的参数
		// 正常情况下回解析成'属性名=属性值&'的格式的
		// 但是这里是图片,就不用解析
		processData: false,
		// 告诉$.ajax方法不要设置参数类型
		// 因为请求参数的类型在formData对象中已经设置了
		contentType: false,
		success: function (response) {
			console.log(response)
			// 设置图片的名字
			$('#thumbnail').val(response[0].cover);
		}
	})
});

// 当添加文章表单提交的时候
$('#addForm').on('submit', function () {
	// 获取管理员在表单中输入的内容
	var formData = $(this).serialize();
	// 向服务器端发送请求 实现添加文章功能
	$.ajax({
		type: 'post',
		url: '/posts',
		data: formData,
		success: function () {
			// 文章添加成功 跳转到文章列表页面
			location.href = '/admin/posts.html'
		}
	})
	// 阻止表单默认提交的行为
	return false;
});

// 获取浏览器地址栏中的id参数,当修改文章的时候id有值,当添加文章的时候id没有值
var id = getUrlParams('id');
if (id != -1) { // 当前管理员是在做修改文章操作
	// 根据id获取文章的详细信息
	$.ajax({
		type: 'get',
		url: '/posts/' + id,
		// 文章详情数据获取成功
		success: function (response) {
			console.log(response);
			$.ajax({
				url: '/categories',
				type: 'get',
				// 分类列表数据获取成功
				success: function (categories) {
					response.categories = categories;
					console.log(response)
					// 将文章详情数据+分类列表数据渲染到模板中
					var html = template('modifyTpl', response);
					$('#parentBox').html(html);
				}
			})
			
		}
	})
}

// 从浏览器的地址栏中获取查询参数
function getUrlParams(name) {
	// location.search 获取的是?uname=ANDY
	// substr(1) 把?去掉
	// split('&') 利用&把字符串分割为数组 
	var paramsAry = location.search.substr(1).split('&');
	// 循环数据
	for (var i = 0; i < paramsAry.length; i++) {
		var tmp = paramsAry[i].split('=');
		if (tmp[0] == name) {
			// 获取第二个值
			return tmp[1];
		}
	}
	return -1;
}

// 当修改文章信息表单发生提交行为的时候 要使用委托
$('#parentBox').on('submit', '#modifyForm', function () {
	// 获取管理员在表单中输入的内容
	var formData = $(this).serialize()
	// 获取管理员正在修改的文章id值
	var id = $(this).attr('data-id');
	$.ajax({
		type: 'put',
		url: '/posts/' + id,
		data: formData,
		success: function () {
			location.href = '/admin/posts.html';
		}
	})
	// 阻止表单默认提交行为
	return false;
});