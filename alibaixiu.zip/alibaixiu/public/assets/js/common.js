// 数据管理(admin)界面的公共js文件

// 退出登录
$('#logout').on('click', function () {
    var isConfirm = confirm('您真的要退出吗?');
    if (isConfirm) {
      // alert('用户点击了确认按钮')
      $.ajax({
        type: 'post',
        url: '/logout',
        // 退出成功
        success: function () {
          location.href = 'login.html';
        },
        error: function () {
          alert('退出失败')
        }
      })
    }
  });

// 处理日期时间格式
function formateDate(date) {
  // 将日期时间字符串转换成日期对象
  date = new Date(date);
  return date.getFullYear() + '-' + (date.getMonth() + 1) + '-' + date.getDate()
}

// 每个界面都要请求,所以放到common.js里面
// 向服务器端发送请求 索要登录用户信息,如果登录后才会返回信息
$.ajax({
  type: 'get',
  // userId是通过登录拦截功能获取的
  url: '/users/' + userId,
  success: function (response) { // 登录了
    // 设置头像
    $('.avatar').prop('src', response.avatar)
    // 设置昵称 后代选择器 
    $('.profile .name').html(response.nickName)
  }
})