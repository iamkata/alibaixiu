// 修改密码表单提交的时候

// 当修改密码表单发生提交行为的时候
$('#modifyForm').on('submit', function () {
	// 获取用户在表单中输入的内容
	var formData = $(this).serialize();
	// 调用接口 实现密码修改功能
	$.ajax({
		url: '/users/password',
		type: 'put',
		data: formData,
		success: function () {
			// 跳转登录界面
			location.href = "/admin/login.html"
			alert('密码修改成功');
		},
		error: function () {
			alert('密码修改失败');
		}
	})
	// 阻止表单默认提交的行为
	return false;
});